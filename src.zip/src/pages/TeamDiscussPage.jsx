function TeamDiscussPage() {}

export default TeamDiscussPage;
